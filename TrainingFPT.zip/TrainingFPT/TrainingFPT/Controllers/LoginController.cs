﻿using Microsoft.AspNetCore.Mvc;

namespace TrainingFPT.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
